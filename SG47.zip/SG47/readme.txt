sudo apt-get install nodejs
sudo apt-get install npm
sudo npm install -g nodemailer --save
sudo npm update nodemailer
npm install -g nodemailer
##########################
sudo npm uninstall nodemailer
##########################
npm install moment --save 
npm install colors --save 
npm install figlet --save 
npm install fs --save


SG47 Version 1.0.0 

Tool for sending emails with a lot of customization. developed using node.js based on nodemailer

Node Link : https://nodejs.org/en/download/

### TAGS 

{random_letternumberuplow_11}
{random_letternumberuplow_10}
{email}
{random_shortlink}


### Features SG47 Version 1.0.0

-   support smtp without auth
-   random tag for text customization
-   multy shortlink
-   send using http proxy
-   delay every emails
-   support pdf attachment
-   support custom headers
-   multy random smtp
-   multy random subject, fromname, fromemail
-   pause for a few seconds after how many emails
-   logs for failed deliveries

Coder : P05TM4N
ICQ : https://icq.im/Postman
