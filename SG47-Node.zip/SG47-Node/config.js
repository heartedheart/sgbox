// multi smtp only duplicate as many objects as possible
exports.smtp = [
	{
		host	: "smtp.1und1.de",
		port	: "587",
		auth	: true, 
		user 	: "Spiegel.m@spiegel-Werkzeugbau.de",
		pass	: "Markus123!"
    }
];

// Message Info
exports.message = [
	{
		fromName	: "{username} Excel-{random_number_4}",
		fromEmail	: "Spiegel.m@spiegel-Werkzeugbau.de",
		subject		: "Remittance Report for Tuesday 09/01/2020 #{random_number_4}",
	}
];

// Multy shortlink
exports.shortlink = [
	'https://google.com/',
	'https://javhd.com/',
	'https://facebook.com/',
	'https://yahoo.com',
	'https://youtube.com'
]

exports.send = {
	delay			: 2, // Seconds per send
	pauseAfter		: 0, // Pause after how many emails
	pauseFor		: 0, // Pause for how many seconds
	useHeader		: true, // if true it will use the custom header set at custom_headers
	useAttach		: true, // if true it will use the attachment that is set in the attachment
	useHttpProxy	: false, // if true then send will use the http proxy that has been set
	text			: "this is the text version", // this is the text version of the html letter, it will be displayed if the html cannot be displayed
	letter 			: "letter.html", // HTML Message
	list 			: "emails.txt"  // Emails File Name
};

exports.proxy = {
	http 	: "127.0.0.1:808" // Proxy
};

exports.attach = {
file 	: "Rem_Advice-398583.html" // Attach File can be pdf or anything
};

exports.custom_headers = {
	KONTOL 	: "zEtNDFmMC05NWYxLWQ5NJDYEISdnaiwYefkSnsuemYyM2E0ZmIxMAAQAJJBmmxztw" // can be filled at will but can't use random tags
};