SG47 Version 1.0.0 

Tool for sending emails with a lot of customization. developed using node.js based on nodemailer

### TAGS 

{random_letternumberuplow_11}
{random_letternumberuplow_10}
{email}
{random_shortlink}


### Features SG47 Version 1.0.0

-   support smtp without auth
-   random tag for text customization
-   multy shortlink
-   send using http proxy
-   delay every emails
-   support pdf attachment
-   support custom headers
-   multy random smtp
-   multy random subject, fromname, fromemail
-   pause for a few seconds after how many emails
-   logs for failed deliveries


Regards, SG47 (one of the best email senders prv8 code for SG)