<?php

// setting all needs here

$settings['multy']['smtp'][]    = 
[ "host" => "mintaka.orion.rs", 
"port" => "587",
 "security" => "tls",
 "username" => "info@ringsport.rs",
 "password" => "HNK@Pm,)m@T$" ];

 
$settings['multy']['message'][] = [ "subject" => "test: ##random_mix_10##", "email" => "info@ringsport.rs", "name" => "test ##random_mix_10##" ];

$settings['main'] = [

        "delay_after"       => "1",
        "delay"             => "1",
        "html_file"         => "letter.html",
        "mailist_file"      => "mailist.txt",
        "attachment"        => "",
        "attachment_rename" => "",
        "charset"           => "iso-8859-1",
        "encoding"          => "8bit",
        
];

$settings['headers'] = [

        'X-Originating-IP' => '51.105.31.8',
        'Authentication-Results' => 'mta4484.mail.gq1.yahoo.com',
        'Received' => 'zmhKkw3qDoenBzsBiOa8b6cMT030a57tZL8+fvTDYPQgKzI8lnPGwm+QDKjGU8KZ 2401:db00:3020:b009:face:0000:0039:0000',

];

$settings['links'] = [

        "https://google.com/",
        "https://bing.com/",
];